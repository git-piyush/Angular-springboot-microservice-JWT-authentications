package com.piyush.setting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SettingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
